from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Создаем объект опций Chrome
options = webdriver.ChromeOptions()

# Установите и используйте ChromeDriver с помощью WebDriver Manager
service = Service(ChromeDriverManager().install())
browser = webdriver.Chrome(service=service, options=options)

try:
    # Открываем страницу
    browser.get('https://monopoly-one.com/auth')

    # Вводим адрес электронной почты
    email_field = WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.ID, 'auth-form-email')))
    email_field.send_keys('rakitine558@gmail.com')

    # Вводим пароль
    password_field = WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.ID, 'auth-form-password')))
    password_field.send_keys('04112005ER23072015SR')

    # Нажимаем на кнопку "Войти"
    login_button = WebDriverWait(browser, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, '.btn.btn-ok')))
    login_button.click()


finally:
    # Закрываем браузер после выполнения действий
    browser.quit()
